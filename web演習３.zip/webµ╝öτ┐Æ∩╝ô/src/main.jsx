import "bulma/css/bulma.css";

import { createRoot } from "react-dom";
import App from "./App";

createRoot(document.querySelector("#content")).render(<App />);